function GetDaysInMonth(month as Integer, year as Integer) as Integer
    if month = 2
        if (year mod 4 = 0 and year mod 100 <> 0) or (year mod 400 = 0)
            return 29
        else
            return 28
        end if
    else if month = 4 or month = 6 or month = 9 or month = 11
        return 30
    else
        return 31
    end if
end function

function GetDayOfWeek(day as Integer, month as Integer, year as Integer) as Integer
    ' Returns 0 (Sunday) to 6 (Saturday)
    ' Using Zeller's congruence or just roDateTime
    date = CreateObject("roDateTime")
    date.FromISO8601String(FormatYear(year) + "-" + FormatMonth(month) + "-" + FormatDay(day) + "T12:00:00Z")
    return date.GetWeekday()
end function

function FormatYear(year as Integer) as String
    return year.ToStr()
end function

function FormatMonth(month as Integer) as String
    m = month.ToStr()
    if month < 10 then m = "0" + m
    return m
end function

function FormatDay(day as Integer) as String
    d = day.ToStr()
    if day < 10 then d = "0" + d
    return d
end function

function GetMonthName(month as Integer) as String
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return months[month - 1]
end function
